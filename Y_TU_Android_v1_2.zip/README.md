# ¿Y TÚ? — Android 1.2

Versión Android instalable del prototipo ¿Y TÚ? by z13.

## Novedad 1.2
- Conexión Firebase mediante REST.
- Inicio de sesión anónimo de Firebase.
- Guardado de votos y mensajes en Firestore.
- Cálculo de porcentajes de la comunidad a partir de votos reales.
- Reintento automático si caduca el token.
- Modo local sigue funcionando si no se configura Firebase.

## Configuración online
Desde Perfil → Configuración/Conectar datos reales, introduce el Project ID y Web API Key del proyecto Firebase.
Activa Authentication → Anonymous y crea Firestore Database.

## Compilación
El workflow de GitHub Actions genera `app-debug.apk` como artifact.
