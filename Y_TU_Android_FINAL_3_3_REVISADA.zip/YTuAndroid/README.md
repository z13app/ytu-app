# ¿Y TÚ?

Versión Android de prueba de **¿Y TÚ? — Descubre cómo piensa el mundo.**

## v1.3
- WebView con la interfaz del prototipo.
- Perfil/avatar y foto desde el dispositivo.
- Compartir dilemas mediante el menú nativo de Android.
- Persistencia local del perfil y datos del prototipo.
- Preparado para seguir conectando backend, usuarios, votos, chat, grupos, parejas, duelos y rankings reales.

### Compilación
El workflow de GitHub Actions construye `assembleDebug` y publica la APK como artefacto.
