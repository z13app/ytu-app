# ¿Y TÚ? — proyecto Android

Este proyecto contiene la versión Android de **¿Y TÚ? — Descubre cómo piensa el mundo.**

## Compilar directamente desde el móvil

No necesitas Android Studio en un ordenador. El proyecto incluye un flujo de **GitHub Actions** que compila la APK en la nube.

1. Desde el móvil, entra en GitHub y crea un repositorio nuevo, por ejemplo `ytu-app`.
2. Sube **todo el contenido de esta carpeta** al repositorio (no solo el HTML y no el ZIP dentro del repositorio).
3. Abre la pestaña **Actions** del repositorio.
4. Entra en **Construir APK ¿Y TÚ?**.
5. Pulsa **Run workflow** si GitHub no lo ha iniciado automáticamente.
6. Cuando termine correctamente, abre la ejecución y baja a **Artifacts**.
7. Descarga `YTU-debug-apk`, descomprímelo y encontrarás `app-debug.apk`.
8. Abre la APK en tu Android para instalar la versión de prueba.

### Importante
- Esta APK es una **versión de prueba** basada en el prototipo actual.
- Todavía no incluye servidor real para usuarios, votos globales, chat online, grupos, duelos y rankings compartidos entre móviles.
- No publiques esta APK en Google Play todavía. Primero probamos y después añadimos backend, cuentas, moderación, privacidad, enlaces compartidos y publicación.
- No hace falta pagar para hacer esta compilación de prueba mediante GitHub Actions.


## Versión 1.1 — conexión de datos reales preparada

La APK ahora conserva votos/puntos/racha y chat en el dispositivo, y contiene una conexión opcional con Firebase para empezar a guardar votos y mensajes en la nube.

Para activar la nube hay que crear un proyecto Firebase del propietario de la app, activar **Authentication > Anonymous** y crear **Cloud Firestore**. Después, desde Perfil > **Conectar datos reales**, se introducen el Project ID y la Web API Key.

Reglas iniciales de prueba de Firestore (NO son las reglas definitivas de producción):

```
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Antes de publicar habrá que sustituir estas reglas por reglas estrictas, añadir perfiles, amigos, grupos, parejas, duelos, moderación y control de privacidad.
