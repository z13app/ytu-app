# ¿Y TÚ? — proyecto Android

Este proyecto contiene la versión Android de **¿Y TÚ? — Descubre cómo piensa el mundo.**

## Compilar directamente desde el móvil

No necesitas Android Studio en un ordenador. El proyecto incluye un flujo de **GitHub Actions** que compila la APK en la nube.

1. Desde el móvil, entra en GitHub y crea un repositorio nuevo, por ejemplo `ytu-app`.
2. Sube **todo el contenido de esta carpeta** al repositorio (no solo el HTML y no el ZIP dentro del repositorio).
3. Abre la pestaña **Actions** del repositorio.
4. Entra en **Construir APK ¿Y TÚ?**.
5. Pulsa **Run workflow** si GitHub no lo ha iniciado automáticamente.
6. Cuando termine correctamente, abre la ejecución y baja a **Artifacts**.
7. Descarga `YTU-debug-apk`, descomprímelo y encontrarás `app-debug.apk`.
8. Abre la APK en tu Android para instalar la versión de prueba.

### Importante
- Esta APK es una **versión de prueba** basada en el prototipo actual.
- Todavía no incluye servidor real para usuarios, votos globales, chat online, grupos, duelos y rankings compartidos entre móviles.
- No publiques esta APK en Google Play todavía. Primero probamos y después añadimos backend, cuentas, moderación, privacidad, enlaces compartidos y publicación.
- No hace falta pagar para hacer esta compilación de prueba mediante GitHub Actions.
